//
//  Bearer.swift
//  AnimalSpotter
//
//  Created by Ben Gohlke on 5/8/19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

import Foundation

struct Bearer: Codable {
    let token: String
}
