# iOS Guided Project Starter: Animal Spotter Part II

This is a starter project for the module _GET and POST Requests with Basic Authentication_ in the sprint _iOS Networking Basics_.

Begin by forking it to your own GitHub account, then cloning it to your local machine.

