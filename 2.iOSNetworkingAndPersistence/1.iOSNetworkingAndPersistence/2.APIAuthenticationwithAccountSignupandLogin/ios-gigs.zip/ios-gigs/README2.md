



## Part 2 - Models

1. This API also uses Bearer token authentication. Create a `Bearer` swift file and struct. An example of the JSON logging in will return is as follows:
                //big, long token that's used to authenticate requests

``` JSON
{
  "id": 4,
  "token": "uLCa2hVZ9\/nWsp670qhXucl5A2TZsxr5Mgap5iCAiwY=",
  "userId": 1
}
```

    You will only need the token as a property in your struct in this application, but you are welcome to create properties for all of these key-value pairs.

    2. Create a `User` swift file and struct that will be used to hold a user's login information. Include the following:

    - A `username` String
    
    - A `password` String

**NOTE: This API expects the encoded User object's keys to be "username" and "password". If you wish to give the properties different names for some reason, you will need to make a coding keys enum to map the new property names to the correct keys the API expects.**

## Part 3 - GigController

1. Create a new Swift file called "GigController.swift" and make a class in it called `GigController`. This class will be responsible for signing you up, and logging you in for today then additionally creating gigs, and fetching gigs tomorrow. We'll keep everything in this class for simplicity's sake but you may choose to have an "AuthenticationController" to handle the authentication aspect of the API. These design decisions are up to the developer and their team. At this point in your learning, implementing one way or the other shouldn't be something to worry over.


**NOTE: Before you begin the next step, be aware that you will need to add an "application/json" Content-Type header to any POST request, or it will not work properly. As an example, you would add this line once you have a request object:**

```
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
```

3. Following the API's documentation [here](https://github.com/LambdaSchool/ios-gigs/blob/master/APIDocumentation.md), create methods that perform a `URLSessionDataTask` for:

    - Signing up for the API using a username and password. Once you "sign up", you can then log into the API like you did in the guided project this morning.
    
    - Logging in to the API using a username and password. This will give you back a token in JSON data. Decode a `Bearer` object from this data and set the value of bearer property you made in this `GigController` so you can authenticate the requests that require it tomorrow.
    
## Part 4 - View Controllers

### GigsTableViewController

1. In `GigsTableViewController`:

    - Add a property with a new instance of `GigController`. This instance of `GigController` will be used to perform network calls to get the gigs from the API, and be passed to the other view controllers to perform whatever API calls they need to do as well.
    
    - Call `viewDidAppear`. In it, check if the `GigController` property's `bearer` is nil. If it is, then perform the manual segue you made to the `LoginViewController`. We will deal with what happens if it isn't nil tomorrow. For now, just put this line in.
        ```
        // TODO: fetch gigs here
        ```
    
    - Return 0 for the `numberOfRowsInSection` and use this as your implementation of `cellForRowAt` until tomorrow:
    
    ```Swift
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "", for: indexPath)

        return cell
    }
    ```
    
    This way this table view controller will build and run in the simulator so you can run the checks that segue to the `LoginViewController` if the user isn't logged in.
    
2. In `LoginViewController`:

  - Add a `var gigController: GigController!` property that will be used to receive the `GigsTableViewController`'s `GigController` through the `prepare(for segue`.
  
    - Add a property called `loginType` that lets you know which login type the user is trying to perform. (Logging in, or signing up). The best way to implement this is to create an enum with these two cases and have the property's type be that enum.
    
    - In the segmented control's action, based on the new selected segment, change the login type property that you just made, and change the button's title to match the login type.
    
    - In the button's action, based on the `loginType` property, perform the corresponding method in the `gigController` to either sign them up or log them in. If the **sign up** is successful, present an alert telling them they can log in. If the **log in** is successful, dismiss the view controller to take them back to the `GigsTableViewController`.
    

**The API documentation only showed what was required for this module project. For the next module project, you will continue writing this project. The updated API documentation can be found in the day2 branch's README of this repo here: https://github.com/LambdaSchool/ios-gigs/blob/day2/APIDocumentation.md**

