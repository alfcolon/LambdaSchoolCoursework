//
//  fetchDetails.swift
//  Gigs
//
//  Created by alfredo on 1/24/20.
//  Copyright © 2020 Alfredo. All rights reserved.
//

import Foundation

func fetchDetails(for animalName: String, completion: @escaping (Result<Animal, NetworkError>) -> Void) {
    //check for bearer token
    guard let bearer = bearer else { completion(.failure(.noAuth)); return }

    //MARK: - Get URL Request Ready

    let animalNameURL = baseUrl.appendingPathComponent("animals/\(animalName)")
    var request = URLRequest(url: animalNameURL)

    request.httpMethod = HTTPMethod.get.rawValue
    request.setValue("Bearer \(bearer.token)", forHTTPHeaderField: "Authorization")
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        
        //Downcast to HTTPURLResponse to read status code
        let response = response as? HTTPURLResponse
        
        //MARK: - Response Error Handling
        
        switch true {
        case response!.statusCode == 401:
            completion(.failure(.badAuth))
            return
        case error != nil: //something went wrong with connection or other
            print("Error receiving \(animalName) details: \(error!)")
            completion(.failure(.otherError))
            return
        case data == nil:
            completion(.failure(.badData))
            return
        default:
            break
        }
        
        //MARK: -  Decode Data
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .secondsSince1970
        do {
            let animal = try decoder.decode(Animal.self, from: data!)
            completion(.success(animal)) }
        catch {
            print("Error decoding animal object: \(error)")
            completion(.failure(.noDecode))
            return }
    }
    task.resume()
}
