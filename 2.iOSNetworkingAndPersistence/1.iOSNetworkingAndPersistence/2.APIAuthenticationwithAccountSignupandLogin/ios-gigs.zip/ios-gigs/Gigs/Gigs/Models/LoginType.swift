//
//  LoginType.swift
//  Gigs
//
//  Created by alfredo on 1/21/20.
//  Copyright © 2020 Alfredo. All rights reserved.
//

import Foundation

enum LoginType: String{
    case signin
    case signup
}
