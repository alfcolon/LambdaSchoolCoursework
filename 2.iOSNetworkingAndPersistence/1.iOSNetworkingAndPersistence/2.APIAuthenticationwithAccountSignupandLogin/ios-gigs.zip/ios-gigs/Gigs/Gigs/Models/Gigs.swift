//
//  Gigs.swift
//  Gigs
//
//  Created by alfredo on 1/22/20.
//  Copyright © 2020 Alfredo. All rights reserved.
//

import Foundation

struct Gig{
    let title: String
    let dueDate: Date
    let description: String
}
