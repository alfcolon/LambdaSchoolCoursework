//
//  Bearer.swift
//  Gigs
//
//  Created by alfredo on 1/20/20.
//  Copyright © 2020 Alfredo. All rights reserved.
//

import Foundation

struct Bearer: Codable{
    let token: String
}
