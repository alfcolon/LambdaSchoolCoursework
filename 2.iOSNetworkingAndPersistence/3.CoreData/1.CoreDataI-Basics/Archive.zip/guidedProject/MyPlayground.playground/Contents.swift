import UIKit
//
//class Operand {
//    var value: Int
//
//    init(value: Int) {
//        self.value = value
//    }
//}
//
//var operand: Operand?
//
//func addOperand() {
//    operand = Operand(value: 5)
//}
//
//class Test {
//    var operand: Operand
//
//    init(operand: Operand) {
//        self.operand = operand
//    }
//}
//
//var copyTest: Test?
//
//func test() {
//    if let op = operand {
//        let operand = Operand(value: op.value)
//        let test = Test(operand: operand)
//        copyTest = test
//    }
//}
//
//addOperand()
//test()
//if let op = operand {
//    op.value = 10
//}
//
//if let t = copyTest {
//    print(t.operand.value)
//}
//
class Stack {
    var n: Num = Num()
    func add(_ num: Num) {
        self.n = num
        num.add()
        n.value += 1
    }
    
}
struct Num {
    var value = 4
    
    func copy() -> Num {
        let num = Num(value: self.value)
        return num
    }
    mutating func add() {
        value += 21
    }
}
class Test {
    var stack = Stack()
    static var num: Num = Num()
    
    func test() {
        self.stack.add(Test.num.copy())
    }
    func printOut() {
        print(Test.num.value)
    }
}

let t = Test()
t.test()
t.printOut()
