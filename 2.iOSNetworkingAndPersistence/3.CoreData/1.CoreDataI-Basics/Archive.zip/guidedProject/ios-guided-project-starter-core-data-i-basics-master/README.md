# Tasks

This is a guided project starter for the module _Core Data I - Basics_ in the sprint _Core Data_.

Begin by forking it to your own GitHub account, then cloning it to your local machine.
