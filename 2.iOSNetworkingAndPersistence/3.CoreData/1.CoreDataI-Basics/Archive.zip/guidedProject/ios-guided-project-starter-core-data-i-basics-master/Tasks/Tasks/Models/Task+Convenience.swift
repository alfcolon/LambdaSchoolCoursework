//
//  Task+Convenience.swift
//  Tasks
//
//  Created by Alfredo Colon on 7/12/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import CoreData
import Foundation

extension Task {
    @discardableResult convenience init(identifier: UUID = UUID(),
                     name: String,
                     notes: String? =  nil,
                     complete: Bool = false,
                     context: NSManagedObjectContext = CoreDataStack.shared.mainContext
    ) {
        self.init(context: context)
        self.complete = complete
        self.identifier = identifier
        self.name = name
        self.notes = notes
    }
}
