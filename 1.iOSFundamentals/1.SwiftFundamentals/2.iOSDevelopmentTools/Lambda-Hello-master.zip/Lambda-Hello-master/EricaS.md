# Erica Sadun

## Who I am in three words
Enthusiastic. Coder. Geek.

## My passion
I love riding bikes. Cycling is the closest I come to flying under my own power. I don't much like riding the flats because you never get a break from pedaling. My favorite terrain is just slightly hilly, with challenging uphills and refreshing downhills.
