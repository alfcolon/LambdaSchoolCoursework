Name: Conner Alegre
Three words that describe me: Super Cool, Sarcastic, Determined
My favorite hobby outside of programming is Locksmithing.
My favorite animal is my cat Null.
