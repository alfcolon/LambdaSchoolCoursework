Hi, I'm Will.
============

Some Words:
 - Words
 - Tall
 - Programmer

It's actually kinda funny how we're using git; I remember watching the talk 
Torvalds gave at google. He made a pressing case to use it instead of CVS, SVN
or Perforce.

There are a lot of programmers who don't like git, though. It's got issues with
large binary files, which for certain projects, is a lot of what source control
is good for. Hopefully git-annex or similar gets the same treatment from the
Windows team eventually.

