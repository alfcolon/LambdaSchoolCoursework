#About Me (Alternate Reality)

**List three words that describe you.**

Hello, my name is Paul and three words that describe me are brash, loud, and short.

**Write a few sentences or a paragraph about your favorite hobby, your favorite animal, or another personal favorite suitable for sharing on a public site.**

I enjoy shopping, being lazy, playing water polo and hunting the most dangerous animals for sport. My favorite animal is the chihuahua. Yo Quiero Taco Bell! Also, Donald Trump is the best president of all time.

Disclaimer: The last statement is most emphatically false.
