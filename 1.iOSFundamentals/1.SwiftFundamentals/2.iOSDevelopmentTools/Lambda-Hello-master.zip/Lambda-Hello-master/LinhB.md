# Linh Bouniol

Three words that best describe me:
 - Creative
 - Curious
 - Multi-lingual
 
 I really like to watch anime and make figures of anime characters out of paper. I use an art form called quilling to twirl thin strips of paper into 3D shapes. I also like to sleep! 😴💤
