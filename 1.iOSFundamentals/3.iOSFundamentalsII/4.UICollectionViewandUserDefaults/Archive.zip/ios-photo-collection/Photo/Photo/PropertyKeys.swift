//
//  PropertyKeys.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import Foundation

extension String {
    static let cellID = "PhotoCell"
    static let addSegue = "AddPhotoSegue"
    static let themeSegue = "SelectThemeModally"
}
