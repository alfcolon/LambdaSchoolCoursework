//
//  PhotosCollectionViewController.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit

class PhotosCollectionViewController: UICollectionViewController {
    
//MARK: -Properties
    
    //1. Create a constant called `photoController` and set its value to a new instance of `PhotoController`.
    let photoController: PhotoController = PhotoController()
    //2. Create a constant called `themeHelper` and set its initial value to a new instance of `ThemeHelper`.
    let themeHelper: ThemeHelper = ThemeHelper()
    
    // MARK: - View
    override func viewDidLoad() {
        super.viewDidLoad()
        setTheme()
        //self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           
           collectionView?.reloadData()
           setTheme()
    }
    
//MARK: -Methods
    
    //5. Create a function called `setTheme()`. This function should:
    func setTheme(){
        //- Get the current `themePreference` from the `themeHelper`. Make sure that it has a value, or return out of the function.
        guard let currentThemePreference = themeHelper.themePreference else { return }
        //- Based on the value, change the collection view's background color depending on whether the theme is dark or the other color you selected.
        print("set theme")
        if currentThemePreference == "Orange"{
            collectionView.backgroundColor = UIColor.orange
        }
        else {
            collectionView.backgroundColor = UIColor.black
        }
    }
    
// MARK: -UICollectionViewDataSource
    
    //3. Fill in the `numberOfItemsInSection` There should be as many cells are there are photos in the `photoController`'s `photos` array.
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
         // #warning Incomplete implementation, return the number of items
         return photoController.photos.count
     }
    //4. Fill in the `cellForItemAt` method. This should pass an instance of `Photo` to the custom cell. **Note:** You will need to cast the cell as `PhotoCollectionViewCell`.
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as? PhotosCollectionViewCell else { return UICollectionViewCell() }
        
        let photo = photoController.photos[indexPath.item]
        cell.photo = photo

        return cell
    }
    
//MARK: -Naviagation
    
    //6. Implement the `prepareForSegue`. You should have three segues to handle.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        switch segue.identifier{
        case "SelectThemeModally": //The segue from the "Select Theme" bar button item should pass the `themeHelper`.
            guard let themeVC = segue.destination as? ThemeSelectionViewController else { return }
            themeVC.modalPresentationStyle = .fullScreen
            themeVC.themeHelper = themeHelper
        case "ShowPhotoDetail": //The segue from the cell should pass the `themeHelper`, `photoController`, and the `photo`.
            guard let detailVC = segue.destination as? PhotoDetailViewController, let cell = sender as? PhotosCollectionViewCell, let indexPath = self.collectionView.indexPath(for: cell) else { return }
            let photo = photoController.photos[indexPath.item]
            detailVC.themeHelper = themeHelper
            detailVC.photoController = photoController
            detailVC.photo = photo
        case "AddPhotoSegue": //The segue from the "Add" bar button item should pass the the `themeHelper` and the `photoController`.
            guard let detailVC = segue.destination as? PhotoDetailViewController else { return }
            detailVC.themeHelper = themeHelper
            detailVC.photoController = photoController
        default:
            return
        }
    }
}
