//
//  ThemeSelectionViewController.swift
//  Photo
//
//  Created by alfredo on 12/14/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit

class ThemeSelectionViewController: UIViewController {
    
//MARK: -Properties

    //2. Create a `themeHelper: ThemeHelper?` variable in this subclass.
    var themeHelper: ThemeHelper?

//MARK: -View

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
//MARK: -IBActions
    
    //6. Add an action from each button. Call them `selectDarkTheme` and `selectYourColorHereTheme`.
    @IBAction func selectDarkTheme(_ sender: Any) {
        //1. In the `selectDarkTheme` action, call the `themeHelper`'s `setThemePreferenceToDark` method. Then call `dismiss(animated: Bool, completion: ...)`. Set `animated` to `true` and `completion` to `nil`.
        guard let themeHelper = themeHelper else { return }
        themeHelper.setThemePreferenceToDark()
        dismiss(animated: true, completion: nil)
    }
    @IBAction func selectOrangeTheme(_ sender: Any) {
        guard let themeHelper = themeHelper else { return }
        themeHelper.setThemePreferenceToOrange()
        dismiss(animated: true, completion: nil)
    }
}
