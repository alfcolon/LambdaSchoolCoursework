//
//  PhotoDetailViewController.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit
import Photos

class PhotoDetailViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

//MARK: -IBOutlets
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var addPhotoButton : UIButton!
    //    2. Create the following variables in this subclass:
    //    - `photoController: PhotoController?`
    //    - `photo: Photo?`
    //    - `themeHelper: ThemeHelper?`
    
    //MARK: -Properties
    var photoController : PhotoController?
    var photo : Photo?
    var themeHelper : ThemeHelper?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
//MARK: -Methods
    
    //1. Create a `setTheme` function. This should do the same thing as the `setTheme` method in your collection view controller, except that it should change the view controller's `view`'s background color instead.
    func setTheme() {
        guard let themeHelper = themeHelper else { return }
        if let themePreference = themeHelper.themePreference {
            if (themePreference == "Dark") {
                view.backgroundColor = UIColor.darkGray
            } else if (themePreference == "Blue") {
                view.backgroundColor = UIColor.blue
            }
        }
    }
    //2. Create an `updateViews` function.
    func updateViews() {
        setTheme()
        guard let photo = photo else { return }
        imageView.image = UIImage(data: photo.imageData)
        textField.text = photo.title
    }
    func presentImagePickerController() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else { return }
        let imagePicker = UIImagePickerController()
           
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
           
        present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
        imageView.image = image
    }
    
//MARK: -IBActions
    
    //4. The `addImage` action should present a `UIImagePickerController` that allows the user to select an image to add to the `Photo` object.
    //**Note:** Make sure you request authorization to access the photo library, and add the "Privacy - Photo Library Usage Description" key-value pair in the info.plist.
    //**Note:** You will need to adopt the `UIImagePickerControllerDelegate` and implement the `didFinishPickingMediaWithInfo` method to get the image the user selects, then dismiss the image picker. You will also need to adopt the `UINavigationControllerDelegate`.
    @IBAction func addPhoto(_ sender: Any) {
     let imagePicker = UIImagePickerController()
           imagePicker.delegate = self
           
           let alertcontroller = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
           
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           alertcontroller.addAction(cancelAction)
           
           if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
               let photoLibraryAction = UIAlertAction(title: "Photo Library", style: .default, handler: {
                   (_) in imagePicker.sourceType = .photoLibrary
                   self.present(imagePicker, animated: true, completion: nil)
               })
               alertcontroller.addAction(photoLibraryAction)
           }
           
           present(alertcontroller, animated: true, completion: nil)
    }
    //3. The "Save" bar button item's action should either update the `photo` if it has a value, or create a new instance of `photo` using the methods in the `photoController`. "Pop" the view controller afterwards.
    @IBAction func savePhoto(_ sender: Any) {
        if let photo = photo {
        photoController?.update(photo: photo, named: photo.title, with: photo.imageData)
             navigationController?.popViewController(animated: true)
         } else {
             guard let title = textField.text,
                 let imageData = imageView.image?.pngData() else { return }
            photoController?.createPhoto(data: imageData, title: title)
             navigationController?.popViewController(animated: true)
         }
    }
}
