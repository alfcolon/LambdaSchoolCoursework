//
//  Photo.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import Foundation
//1. Create a swift file called "Photo.swift".
//2. Create a struct `Photo` in it with the following properties:
//    - An `imageData: Data` variable.
//    - A `title: String` variable.
//3. Adopt the `Equatable Protocol.
struct Photo: Equatable, Codable {
    var imageData: Data
    var title: String
}
