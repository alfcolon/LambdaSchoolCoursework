//
//  PhotoController.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import Foundation
//2. Create a class `PhotoController`.
class PhotoController {

// MARK: - Properties
    
    //3. Add a `photos` varable of type `[Photo]`, and set its initial value to an empty array.
    var photos: [Photo] = []

// MARK: - Methods
    
    init() {
        loadFromPersistentstore()
    }
    //4. Add a "Create" method
    func createPhoto(data: Data, title: String) {
        //Initialize a new instance of `Photo`
        let photo = Photo(imageData: data, title: title)
        //append it to the `photos` array
        photos.append(photo)
        //update persisent data
        saveToPersistentStore()
    }
    //5. Add an "Update" method that takes in `Photo`,`Data`, and `String` parameters.
     func update(photo: Photo, named title: String, with data: Data) {
        guard let index = photos.firstIndex(of: photo) else { return }
        let photo = Photo(imageData: data, title: title)
        photos[index] = photo
        saveToPersistentStore()
     }
    
// MARK: - Privates
    private var persistentFileURL: URL? {
        let fileManager = FileManager.default
        guard let dir = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        return dir.appendingPathComponent("Photos.plist")
    }
    private func saveToPersistentStore() {
        guard let fileURL = persistentFileURL else { return }
        do {
            let encoder = PropertyListEncoder()
            let data = try encoder.encode(photos)
            try data.write(to: fileURL)
        } catch {
            print("Error saving photos data: \(error)")
        }
    }
    private func loadFromPersistentstore() {
        let fileManager = FileManager.default
        guard let fileURL = persistentFileURL,
            fileManager.fileExists(atPath: fileURL.path) else { return }
        do {
            let data = try Data(contentsOf: fileURL)
            let decoder = PropertyListDecoder()
            photos = try decoder.decode([Photo].self, from: data)
        } catch {
            print("Error loading photos data: \(error)")
        }
    }
}
