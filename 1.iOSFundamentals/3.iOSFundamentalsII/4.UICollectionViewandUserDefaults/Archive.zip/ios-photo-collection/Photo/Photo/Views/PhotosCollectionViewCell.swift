//
//  PhotosCollectionViewCell.swift
//  Photo
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit

//Update new photo in PhotoCollection
class PhotosCollectionViewCell: UICollectionViewCell {
    
//MARK: - IBOutlets
    
    @IBOutlet weak var photosImageView: UIImageView!
    @IBOutlet weak var photoLabel: UILabel!
    
//MARK: - Properties
    
    //1. Create a `photo: Photo?` variable.
    var photo: Photo? {
        //3. Add a `didSet` property observer to the `photo` variable. Call `updateViews` inside of it.
        didSet {
            updateViews()
        }
    }
    
//MARK: - Methods
    
    //2. Create an `updateViews()` function. You should be familiar with this function.
    func updateViews() {
        guard let photo = photo else { return }
        
        photoLabel.text = photo.title
        photosImageView.image = UIImage(data: photo.imageData)
    }
}
