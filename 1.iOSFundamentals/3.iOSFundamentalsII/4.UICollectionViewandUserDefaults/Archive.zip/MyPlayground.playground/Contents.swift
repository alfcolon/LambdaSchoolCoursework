import UIKit
import Foundation

//final class SinglyLinkedListNode {
//    var data: Int
//    var next: SinglyLinkedListNode?
//
//    public init(nodeData: Int) {
//        self.data = nodeData
//    }
//}
//
//final class SinglyLinkedList {
//    var head: SinglyLinkedListNode?
//    var tail: SinglyLinkedListNode?
//
//    public init() {}
//
//    public func insertNode(nodeData: Int) {
//        self.insertNode(node: SinglyLinkedListNode(nodeData: nodeData))
//    }
//
//    private func insertNode(node: SinglyLinkedListNode) {
//        if let tail = tail {
//            tail.next = node
//        } else {
//            head = node
//        }
//
//        tail = node
//    }
//}
//func printLinkedList(head: SinglyLinkedListNode?) -> Void {
//    // var current: SinglyLinkedListNode? = head
//    // while true{
//    //     if let node = current{
//    //         print(node.data)
//    //         if let next = node.next{
//    //             current = next
//    //         }
//    //         else{
//    //             break
//    //         }
//    //     }
//    //     else{
//    //         break
//    //     }
//    // }
//}
//
//guard let llistCount = Int((readLine()?.trimmingCharacters(in: .whitespacesAndNewlines))!)
//else { fatalError("Bad input") }
//
//let llist = SinglyLinkedList()
//
//for _ in 1...llistCount {
//    guard let llistItem = Int((readLine()?.trimmingCharacters(in: .whitespacesAndNewlines))!)
//    else { fatalError("Bad input") }
//    llist.insertNode(nodeData: llistItem)
//}
//
//printLinkedList(head: llist.head)
//constantly filter and return count
//or add
func maximumToys(prices: [Int], k: Int) -> Int {
    var availableCash: Int = k
    var itemPrices: [Int] = prices
    itemPrices = itemPrices.sorted()
    for n in itemPrices{
        availableCash -= n
        itemPrices.filter{ $0 <= availableCash }
    }
    print(prices.count)
    return itemPrices.count
}
var answer = maximumToys(prices: [4,2,1], k: 3)
print(answer)
