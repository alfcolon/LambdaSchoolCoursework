//
//  Star.swift
//  Stars
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import Foundation


//Codeable: endcode and decode custom objects
struct Star: Codable{
    var name: String
    var distance: Double
}
