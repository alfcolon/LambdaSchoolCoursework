//
//  StarController.swift
//  Stars
//
//  Created by alfredo on 12/11/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import Foundation
//source of truth for the app
//CRUD
//Crud
//Read
//Update
//Delete
//save & load
class StarController{
    //load up persistent data
    init(){
        loadFromPersistenceStore()
    }
    //Access Control - private(set) means it can only be accessed in StarController
    private(set) var stars: [Star] = []
    //Creating file to save data to
    //navigate to file to store data
    private var persistentFileURL: URL? {
        //iPhone's filesytem
        let fileManager = FileManager.default
        //for home directory inside user directory
        guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {return nil}
        //creating a file path //USers/johnnyhicks/Document/stars.plist
        return documents.appendingPathComponent("stars.plist")
    }
    
    //Create
    //@discardable = you can call the function without doing anything with the return value
        //avoid compiler warning
        //when you don't always want to use the result
    @discardableResult func createStar(named name: String, withDistance distance: Double) -> Star{
        let star = Star(name: name, distance: distance)
        stars.append(star)
        //call save method whenver a star is created
        saveToPersistenceStore()
        return star
    }
    // Save and Load
    func saveToPersistenceStore(){
        guard let url = persistentFileURL else { return }
        
        //~1:40
        
        //in order to save do:
        do {
            let encoder = PropertyListEncoder()
            let data = try encoder.encode(stars) //automatically throws an error
            try data.write(to: url)
        } catch {
            print("Error saving stars data: \(error)")
        }
    }
    func loadFromPersistenceStore(){
        // Data in Plist to Star objects
        let fileManager = FileManager.default
        guard let url = persistentFileURL,
            fileManager.fileExists(atPath: url.path) else { return }
        
        //convert propertyListData back into star objects
        do {
            let data = try Data(contentsOf: url)
            let decoder = PropertyListDecoder()
            stars = try decoder.decode([Star].self, from: data)
        } catch {
            print("Error loading stars data: \(error)")
        }
    }
}
