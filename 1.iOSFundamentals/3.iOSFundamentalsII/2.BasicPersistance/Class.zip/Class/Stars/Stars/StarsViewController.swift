//
//  StarsViewController.swift
//  Stars
//
//  Created by alfredo on 12/10/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit

class StarsViewController: UIViewController {

    var starController = StarController()
    // MARK: - IBOutlets
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var distanceTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    // MARK: - IBActions
    @IBAction func printStars(_ sender: UIButton) {
    }
    
    @IBAction func createStars(_ sender: UIButton) {
        //avoid incomplete Stars
        //parse output
        guard let name = nameTextField.text,
            let distanceString = distanceTextField.text,
            !name.isEmpty,
            !distanceString.isEmpty,
            let distance = Double(distanceString) else { return }
            
        starController.createStar(named: name, withDistance: distance)
        //update text fields
        nameTextField.text = ""
        distanceTextField.text = ""
        //put the cursor back in the nameTextField //becomes active
        nameTextField.becomeFirstResponder()
        //after star is created reload the textview
        tableView.reloadData()
    }
}

//will be the tableview datasource for tableview
  //conform to UITableViewDataSource
extension StarsViewController: UITableViewDataSource{
    //get number of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return starController.stars.count
    }
    //1:23
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "StarCell", for: indexPath)
            as? StarTableViewCell else { return UITableViewCell() }
    let star = starController.stars[indexPath.row]
    cell.star = star
    return cell
    }
}
