//
//  VocabularyWord.swift
//  Swift Vocabulary
//
//  Created by alfredo on 11/13/19.
//  Copyright © 2019 alfredo. All rights reserved.
//

import UIKit

//2. Create a struct inside the file called `VocabularyWord`
struct VocabularyWord
{
    let word: String
    let definition: String
}
