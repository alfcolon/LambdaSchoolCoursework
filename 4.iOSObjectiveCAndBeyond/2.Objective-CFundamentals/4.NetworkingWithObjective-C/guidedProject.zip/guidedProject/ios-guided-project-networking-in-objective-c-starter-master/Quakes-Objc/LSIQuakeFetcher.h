//
//  LSIQuakeFetcher.h
//  Quakes-Objc
//
//  Created by Alfredo Colon on 9/2/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//MARK: - Class Decorations

@class LSIQuake;

//MARK: - TypeDef

//Swift: typeAlias StudentName = String
// ([Quake]?, error: Error?)
typedef void (^LSIQuakeFetcherCompletion)(NSArray<LSIQuake *> * _Nullable quakes, NSError * _Nullable error);

NS_ASSUME_NONNULL_BEGIN

@interface LSIQuakeFetcher : NSObject

//MARK: - Methods

- (void)fetchQuakesInTimeInterval:(NSDateInterval *)interval
                  completionBlock:(LSIQuakeFetcherCompletion)completionBlock;

@end

NS_ASSUME_NONNULL_END
