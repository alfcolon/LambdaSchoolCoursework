//
//  NSDateInterval+LSIDayInterval.h
//  Quakes-Objc
//
//  Created by Alfredo Colon on 9/2/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// We can extend classes that we don't have original source access for

@interface NSDateInterval (LSIDayInterval)

//MARK: - Methods

// + == class method
// If you don't own the class, you need to use a prefix lso_ so that you don't
// have a bug wehre the system randomly chooses an implementation
+ (instancetype)lsi_dateIntervalByAddingDays:(NSInteger)days;
+ (instancetype)lsi_dateIntervalByAddingDays:(NSInteger)days toDate:(NSDate *)date;

@end

NS_ASSUME_NONNULL_END
