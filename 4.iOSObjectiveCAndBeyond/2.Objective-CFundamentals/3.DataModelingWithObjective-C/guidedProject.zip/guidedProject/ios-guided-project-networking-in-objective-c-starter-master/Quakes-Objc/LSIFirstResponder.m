//
//  LSIFirstResponder.m
//  Quakes-Objc
//
//  Created by Alfredo Colon on 8/31/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import "LSIFirstResponder.h"

@implementation LSIFirstResponder

/*
 1. Setter
    - (void)setName:(NSString *)name;
 2. Getter
    - (NSString *)name;
 3. Instance variable (backing store)
    NSString *_name

 Property Rule:
    If you deine all of the getters/setters that are available, you need to
    provide the backing variable (computed property)

    @synthesize matches a property (like name) to an instance variable name that we specify
 */
@synthesize name = _name;

// Define getter
// Swift: var name: String { return name }
- (NSString *)name
{
    return _name;
}
// Conventions: property declaration creates a contract, so we need to copy iy, if it states copy

// Define setter
- (void)setName:(NSString *)name
{
    // Anything we call before the value is set is essentially a willSet
    _name = [name copy];
    // Anything we set after the value is set is essentially a didSet
}

@end
