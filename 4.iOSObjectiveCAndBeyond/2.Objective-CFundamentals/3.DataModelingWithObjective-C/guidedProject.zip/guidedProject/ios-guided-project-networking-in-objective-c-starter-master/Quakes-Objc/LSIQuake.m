//
//  LSIQuake.m
//  Quakes-Objc
//
//  Created by Alfredo Colon on 8/31/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import "LSIQuake.h"

@implementation LSIQuake

-(instancetype)initWithMagnitude:(double)magnitude
                           alert:(NSString *)alert
                        latitude:(double)latitude
                       longitude:(double)longitude
                           place:(NSString *)place
                            time:(NSDate *)time
                            type:(NSString *)type
{
    self = [super init];
    if (self) {
        _magnitude = magnitude;
        _alert = [alert copy];
        _latitude = latitude;
        _longitude = longitude;
        _place = [place copy];
        _time = time;
        _type = [type copy];
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSDictionary *propertiesDictionary = dictionary[@"properties"];
    
    NSNumber *magnitude = propertiesDictionary[@"mag"];
    NSString *place = propertiesDictionary[@"place"];
    
    NSNumber *timeNumber = propertiesDictionary[@"time"];
    NSDate *time = [NSDate dateWithTimeIntervalSince1970:timeNumber.longValue / 1000];
    
    NSString *alert = propertiesDictionary[@"alert"];
    
    // How do we handle when there is no value for a key?
    
    //[SomeType class] == Sometype.self in Swift
    if ([alert isKindOfClass:[NSNull class]]) {
        alert = @"";
    }
    
    NSString *type = propertiesDictionary[@"type"];
    
    NSDictionary *geometryDictionary = dictionary[@"geometry"];
    NSArray *coordinates = geometryDictionary[@"coordinates"];
    
    NSNumber *longitudeNumber = nil;
    NSNumber *latitudeNumber = nil;
    
    // We knoew we have the latitudde and longitude if there are at least tow object in the array
    if (coordinates.count >= 2) {
        longitudeNumber = coordinates[0];
        latitudeNumber = coordinates[1];
    }
    
    // API decision: Do you want to return potentially a half-baked object
    // with some values missing, or if we are missing value(s), reutn nil (no object at all) instead?
    
    if (!(magnitude &&
          place &&
          latitudeNumber &&
          longitudeNumber)) {
        return nil;
    }
    
    self = [self initWithMagnitude:magnitude.doubleValue
                             alert:alert
                          latitude:latitudeNumber.doubleValue
                         longitude:longitudeNumber.doubleValue
                             place:place
                              time:time
                              type:type];

    return self;
}
@end
