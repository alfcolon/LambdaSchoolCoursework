//
//  LSIQuakeTests.m
//  Quakes-ObjcTests
//
//  Created by Alfredo Colon on 8/31/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import <XCTest/XCTest.h>

#import "LSILog.h"
#import "LSIQuake.h"
#import "LSIFileHelper.h"


@interface LSIQuakeTests : XCTestCase

@end

@implementation LSIQuakeTests

- (void)testQuakeParsing
{
    NSData *quakeData = loadfile(@"Quake.json", [LSIQuakeTests class]);
    NSLog(@"Quake: %@", quakeData);
    
    // If this was codable, it would be NSData -> LSIQuake
    
    // NSData -> Dictionary -> LSIQuake
    
    NSError *jsonError = nil;
    NSDictionary *quakeDictionary = [NSJSONSerialization JSONObjectWithData:quakeData options:0 error:&jsonError];
    
    LSIQuake *quake = [[LSIQuake alloc] initWithDictionary:quakeDictionary];
    
    NSLog(@"Quake: @@", quake);
    
    XTCAssertEqualWithAccuracy(1.29, quake.magnitude, 0.0001);
    
    XTCAssertEqualObjects(time, quake.time);
    
    XTCAssertEqualObjects(@"", quake.alert);
    
    XTCAssertEqualObjects(@"earthquake", quake.type);
    
    XTCAssertEqualWithAccuracy(33.66333329999998, quake.latitude, 0.0001);
    XTCAssertEqualWithAccuracy(-116.7776667, quake.magnitude, 0.0001); 
    
    
    
}

@end
