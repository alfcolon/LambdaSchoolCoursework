# ios-guided-project-video-recorder-starter
Starter project for iOS Video Guided Project
