//
//  EarthquakesViewController.swift
//  Quakes
//
//  Created by Paul Solt on 10/3/19.
//  Copyright © 2019 Lambda, Inc. All rights reserved.
//

import UIKit
import MapKit

class EarthquakesViewController: UIViewController {
    
    //MARK: - IBOutlets
    
    @IBOutlet var mapView: MKMapView!
	
    //MARK: - Properties
    
    var quakeFetcher = QuakeFetcher()
    
    //MARK: - ViewController Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.mapView.delegate = self
        self.mapView.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "QuakeView")
        
        self.quakeFetcher.fetchQuakes { (quakes, error) in
            if let error = error {
                NSLog("Error fetching quakes")
            }
            
            guard let quakes = quakes else { return NSLog("No quakes returned...") }
            
            let firstNQuakes = Array(quakes.dropFirst(50))

            DispatchQueue.main.async {
                self.mapView.addAnnotations(firstNQuakes)
                
                //Zoom in to first earthqualk (in the future this could be the largest magitude earthquake)
                
                guard let firstQuake = firstNQuakes.first else { return }
                
                let span = MKCoordinateSpan(latitudeDelta: 0, longitudeDelta: 0)
                let region = MKCoordinateRegion(center: firstQuake.coordinate, span: span)
                
                self.mapView.setRegion(region, animated: true)
            }
        }
    }
}

extension EarthquakesViewController: MKMapViewDelegate {
    
    //Similar to the cellForRow at indexPath of a tableView
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let quake = annotation as? Quake else { fatalError("Only Quake objects are supported right now") }
        
        guard let annotationView = self.mapView.dequeueReusableAnnotationView(withIdentifier: "QuakeView", for: quake) as? MKMarkerAnnotationView else {
            fatalError("Missing a registered map annotation view. Have you done this in the viewDidLoad?")
        }
        
        annotationView.glyphImage = UIImage(named: "QuakeIcon")
        
        switch quake.magnitude {
        case 0...3:
            annotationView.markerTintColor = .systemYellow
        case 3..<5:
            annotationView.markerTintColor = .systemOrange
        case 5.1...:
            annotationView.markerTintColor = .systemRed
        default:
            break
        }
        
        annotationView.canShowCallout = true
        
        let detailView = QuakeDetailView()
        detailView.quake = quake
        
        annotationView.detailCalloutAccessoryView = detailView
        
        return annotationView
    }
}
