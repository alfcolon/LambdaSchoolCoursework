//
//  Quake.swift
//  Quakes
//
//  Created by Dimitri Bouniol Lambda on 1/22/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

import Foundation
import MapKit

enum CodingKeys: String, CodingKey {
    case properties
    case geometry
    
    enum PropertiesKeys: String, CodingKey {
        case magnitude = "mag"
        case place
        case time
    }
    
    enum GeometryKeys: String, CodingKey {
        case coordinates
        
    }
}

class QuakeResults: Decodable {
    let quakes: [Quake]
    
    enum CodingKeys: String, CodingKey {
        case quakes = "features"
    }
}

class Quake: NSObject, Decodable {
    
    //MARK: - Properties
    
    let magnitude: Double
    let place: String
    let time: Date
    let latitude: Double
    let longitude: Double
    
    //MARK: - Init
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        //Get the properties (mag, time, place)
        let propertiesContainer = try container.nestedContainer(keyedBy: CodingKeys.PropertiesKeys.self, forKey: .properties)
        
        self.magnitude = try propertiesContainer.decodeIfPresent(Double.self, forKey: .magnitude) ?? 0.0
        self.place = try propertiesContainer.decode(String.self, forKey: .place)
        self.time = try propertiesContainer.decode(Date.self, forKey: .time)
        
        //Get geometry (latitude and longitude)
        let geometryContainer = try container.nestedContainer(keyedBy: CodingKeys.GeometryKeys.self, forKey: .geometry)
        
        var coordinatesContainer = try geometryContainer.nestedUnkeyedContainer(forKey: .coordinates)
        
        self.longitude = try coordinatesContainer.decode(Double.self)
        self.latitude = try coordinatesContainer.decode(Double.self)
        
        // Call super to initialize the NSObject extension
        super.init()
    }
}

extension Quake: MKAnnotation {
    var coordinate: CLLocationCoordinate2D { return CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude) }
    var title: String? { return self.place }
    var subtitle: String? { return "Magnitude: \(self.magnitude)" }
}
