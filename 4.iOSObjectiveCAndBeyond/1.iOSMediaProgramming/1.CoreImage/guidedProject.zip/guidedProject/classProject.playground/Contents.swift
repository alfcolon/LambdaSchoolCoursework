import CoreImage
import CoreImage.CIFilterBuiltins

enum FilterNames: String {
    case colorControls = "CIColorControls"
}

//Two ways to create a filter
let myFilter = CIFilter(name: "CIColorControls")
let myFilter2 = CIFilter.colorControls()


//ZSetting the brightness

myFilter?.setValue(0.5, forKey: "inputBrightness")

for attribute in myFilter!.attributes {
    print(attribute.key)
}
//print(myFilter?.attributes)
