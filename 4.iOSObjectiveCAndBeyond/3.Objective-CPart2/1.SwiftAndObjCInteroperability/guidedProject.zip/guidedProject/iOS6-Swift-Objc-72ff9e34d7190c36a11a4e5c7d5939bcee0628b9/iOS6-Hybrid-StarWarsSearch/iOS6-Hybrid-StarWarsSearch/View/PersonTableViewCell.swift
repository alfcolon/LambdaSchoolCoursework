//
//  PersonTableViewCell.swift
//  iOS6-Hybrid-StarWarsSearch
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

import Foundation
