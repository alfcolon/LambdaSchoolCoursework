//
//  LSIPerson.h
//  iOS6-Hybrid-StarWarsSearch
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSIPerson : NSObject

@end

NS_ASSUME_NONNULL_END
