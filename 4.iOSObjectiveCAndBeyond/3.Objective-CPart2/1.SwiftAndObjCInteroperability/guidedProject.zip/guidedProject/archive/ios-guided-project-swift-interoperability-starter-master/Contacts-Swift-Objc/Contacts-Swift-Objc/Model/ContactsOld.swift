//
//  Contacts.swift
//  Contacts-Swift-Objc
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

import Foundation

// Any function, initalizer, or property that needs tp be accessed in your obje-c code must be marked with @objc

// In adding the (LSIContact) we are giving the class a new mname (generally adding a prefix) to be used as in Obc-c

@objc (LSIContact)
class Contact: NSObject {
    
    //MARK: - Properties
    
    @objc var name: String
    @objc var relationship: String?
    
    //MARK: - Init
    
    @objc init(name: String, relationship: String?) {
        self.name = name
        self.relationship = relationship
    }
}
