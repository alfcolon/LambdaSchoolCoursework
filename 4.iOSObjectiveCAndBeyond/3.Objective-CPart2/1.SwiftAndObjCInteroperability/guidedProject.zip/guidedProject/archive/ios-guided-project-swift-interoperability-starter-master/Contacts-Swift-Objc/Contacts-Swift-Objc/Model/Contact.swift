//
//  Contact.swift
//  Contacts-Swift-Objc
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Lambda, Inc. All rights reserved.
//

import UIKit

@objc (LSIContact)
class Contact: NSObject {
    
    //MARK: - Properties
    
    var name: String
    var relationship: String?
    
    //MARK: - Init
    
    @objc init(name: String, relationship: String?) {
        self.name = name
        self.relationship = relationship
    }
}
