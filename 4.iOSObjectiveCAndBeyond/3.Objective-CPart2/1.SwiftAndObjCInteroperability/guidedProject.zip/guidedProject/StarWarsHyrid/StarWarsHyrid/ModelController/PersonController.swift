//
//  PersonController.swift
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

import Foundation

class PersonController: NSObject {
    
    private let baseURL = URL(string: "https://swapi.dev/api/people")!
    
    @objc(sharedController)
    static let shared = PersonController()
    
    @objc(searchForPeopleWithSearchTerm:completionHandler:)
    func searchForPeople(with searchTerm: String, completion: @escaping ([Person]?, Error?) -> Void) {
        
        var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: true)!
        let searchItem = URLQueryItem(name: "search", value: searchTerm)
        components.queryItems = [searchItem]
        let url = components.url!
        print(url.absoluteString)
    
        URLSession.shared.dataTask(with: url) { (data, _, error) in
            if let error = error {
                print("error with the url request\n")
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            
            guard let data = data else {
                print("error with the data\n")
                DispatchQueue.main.async {
                    completion(nil, NSError(domain: "PersonControllerErrorDomain", code: 0, userInfo: nil))
                }
                return
            }
            
            do {
                guard let dictionary = try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any] else {
                    print("error with getting info from data\n")
                    let error = NSError(domain: "PersonControllerErrorDomain", code: 1, userInfo: nil);
                    
                    throw error
                }
                
                guard let personDictionaries = dictionary["results"] as? [[String : Any]] else {
                    print("error with turning json into a person dictionary\n")
                    let error = NSError(domain: "PersonControllerErrorDomain", code: 2, userInfo: nil);
                    
                    throw error
                }
//                print("\personDictionaries: \(personDictionaries).count)")
                let people = personDictionaries.compactMap { Person(dictionary: $0) }
                
                print("\nJSON PEOPLE COUNT: \(people.count)")
                DispatchQueue.main.async {
                    // self.people = people
                    completion(people, nil)
                }
            } catch {
                print("error in url catch\n")
                DispatchQueue.main.async {
                    completion(nil, error)
                }
            }
        }.resume()
        
    }
}
