//
//  PersonTableViewCell.swift
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

import UIKit

@objc (LSIPersonTableCell)
class PersonTableViewCell: UITableViewCell {


    //MARK: - IBOutlets
    

    @IBOutlet var birthYearLabel: UILabel!
    @IBOutlet var eyeColorLabel: UILabel!
    @IBOutlet var heightLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    
    
    //MARK: - Properties
    
    @objc var person: Person? {
        didSet {
            self.updateViews()
        }
    }
     
    //MARK:- Methods
    
    private func updateViews() {
        guard let person = person else { return }
        
        self.birthYearLabel.text = person.birthyear
        self.eyeColorLabel.text = person.eyecolor
        self.heightLabel.text = "\(person.height / 100)m"
        self.nameLabel.text = person.name
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

//    override func setSelected(selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

}
