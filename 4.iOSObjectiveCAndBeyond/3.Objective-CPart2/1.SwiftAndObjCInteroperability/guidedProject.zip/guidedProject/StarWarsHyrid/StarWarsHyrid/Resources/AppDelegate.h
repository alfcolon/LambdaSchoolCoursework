//
//  AppDelegate.h
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

