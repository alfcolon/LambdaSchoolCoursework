//
//  LSIPersonSearchTableViewController.h
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LSIPersonSearchTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
