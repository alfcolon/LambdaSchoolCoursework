//
//  LSIPersonSearchTableViewController.m
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import "LSIPersonSearchTableViewController.h"
#import "LSIPerson.h"
#import "StarWarsHyrid-Swift.h"

@class LSIPersonTableViewCell;

@interface LSIPersonSearchTableViewController ()

// TODO: Create a PersonController.swift and make it an instance variable

@property (strong, nonatomic) IBOutlet UISearchBar *searchBar;
@property (nonatomic) NSArray<LSIPerson *> *people;

@end

@implementation LSIPersonSearchTableViewController

// thsi init is called when the storyboard is loaded

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        self.people = @[];

    }
    return self;
}
- (void)viewDidLoad {
    [self.searchBar setDelegate:self];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.people.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    LSIPersonTableCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PersonCell" forIndexPath:indexPath];

    
    LSIPerson *person = self.people[indexPath.row];
    cell.person = person;

    return cell;
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSLog(@"Search bar button clicked");
    // Call the PersonController's search method
    [[PersonController sharedController] searchForPeopleWithSearchTerm:searchBar.text completionHandler:^(NSArray<LSIPerson *> *people, NSError *error) {
        if (error) {
            NSLog(@"Error searching for %@: %@\n", searchBar.text, error);
        }
        self.people = people;
    }];
}

// Use the equivalent of a didSet to reload the tableView on the correct queue.
- (void)setPeople:(NSArray<LSIPerson *> *)people {
    // willSet

    _people = [people copy];
    NSLog(@"new people = %lu", (unsigned long)people.count);
    // didSet
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

@end
