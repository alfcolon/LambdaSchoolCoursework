//
//  LSIPerson.m
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import "LSIPerson.h"

@implementation LSIPerson

//MARK - Init

- (instancetype)initWithName:(NSString *)name birthYear:(NSString *)birthYear height:(double)height eyeColor:(NSString *)eyeColor
{
    self = [super init];
    if (self) {
        _birthyear = birthYear;
        _eyecolor = eyeColor;
        _height = height;
        _name = name;
    }
    return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary
{
    NSString *name = dictionary[@"name"];
    NSString *birthYear = dictionary[@"birth_year"];
    NSString *eyeColor = dictionary[@"eye_color"];
    NSString *heightString = dictionary[@"height"];
    double height = [heightString doubleValue];
    
    if (!name || !birthYear || !eyeColor || !heightString) {
        return nil;
    }
    
    return [self initWithName:name
                    birthYear:birthYear
                       height:height
                     eyeColor:eyeColor];
}
@end
