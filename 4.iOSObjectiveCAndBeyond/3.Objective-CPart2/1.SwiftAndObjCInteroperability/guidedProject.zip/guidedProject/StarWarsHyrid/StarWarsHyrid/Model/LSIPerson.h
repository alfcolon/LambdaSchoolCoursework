//
//  LSIPerson.h
//  StarWarsHyrid
//
//  Created by Alfredo Colon on 9/4/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN //Unless its optional, assume it's non-optional

// Set this to a more normal class name for Wsift
NS_SWIFT_NAME(Person)
@interface LSIPerson : NSObject

//MARK: - Properties

@property (nonatomic, copy, readonly) NSString *birthyear;
@property (nonatomic, copy, readonly) NSString *eyecolor;
@property (nonatomic, readonly) double height;
@property (nonatomic, copy, readonly) NSString *name;


//MARK: - Init

- (instancetype)initWithName: (NSString *)name
                   birthYear:(NSString *)birthYear
                      height:(double)height
                    eyeColor:(NSString *)eyeColor;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

NS_ASSUME_NONNULL_END
