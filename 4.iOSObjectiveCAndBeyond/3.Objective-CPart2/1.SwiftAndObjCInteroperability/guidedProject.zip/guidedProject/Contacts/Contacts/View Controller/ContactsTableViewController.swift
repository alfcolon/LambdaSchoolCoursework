//
//  ViewController.swift
//  Contacts
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

import UIKit

class ContactsTableViewController: UITableViewController {

    
    //MARK: - Properties
    
    let contactsController = ContactsController()
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.contactsController.contacts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell") as? ContactTableViewCell else { return UITableViewCell() }
        
        //TODO: Implement Display Logic
        let contact = self.contactsController.contacts[indexPath.row]
        
        cell.subtitleLabel?.text = contact.relationship
        cell.titleLabel?.text = contact.name
        
        return UITableViewCell()
    }
}
