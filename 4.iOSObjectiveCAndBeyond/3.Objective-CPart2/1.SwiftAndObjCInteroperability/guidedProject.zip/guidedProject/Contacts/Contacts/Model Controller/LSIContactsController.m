//
//  LSIContactsController.m
//  Contacts
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import "LSIContactsController.h"
#import "Contacts-Swift.h"

/*
 If you need to find the name of the automatically generated header file for the swift you want to use in you
 Obj-C code, it is going to be the name of your project and "-Swift.h".
 
 - For example "Journal-Swift.h"
 - If your project has spaces in the name, they will be converted to underscores instead. For example, the header name for the project named "Hybrid Star Wars Search" would be "Hybrid_Star_Wars_Search-Swift.h")
 */

@implementation LSIContactsController

- (instancetype)init
{
    self = [super init];
    if (self) {
        _contacts = @[[[LSIContact alloc] initWithName:@"Spencer" relationship: @"Myself"],
                      [[LSIContact alloc] initWithName:@"Spencer" relationship: @"Myself"],
        ];
    }
    return self;
}

@end
