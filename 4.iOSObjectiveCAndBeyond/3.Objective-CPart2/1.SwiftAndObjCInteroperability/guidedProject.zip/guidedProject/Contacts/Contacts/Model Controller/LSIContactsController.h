//
//  LSIContactsController.h
//  Contacts
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LSIContact;

// Add a name for this contact controller to be bridged into swift as. Generally this will be the name of the class minus the prefix

NS_SWIFT_NAME(ContactsController)
@interface LSIContactsController : NSObject

/*
 Annotating for nullablility
    - nillable means optional
    - nonnull means non-optional
 
 */
@property (nonatomic, readonly, nonnull) NSArray <LSIContact *> *contacts;

@end
