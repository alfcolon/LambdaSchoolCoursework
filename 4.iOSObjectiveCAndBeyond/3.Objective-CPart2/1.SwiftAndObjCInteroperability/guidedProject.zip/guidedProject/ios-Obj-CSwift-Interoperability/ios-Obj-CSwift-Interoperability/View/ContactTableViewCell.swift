//
//  ContactTableViewCell.swift
//  ios-Obj-CSwift-Interoperability
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    //MARK: - IBOutlets
    
    @IBOutlet var subtitleLabel: UILabel!
    @IBOutlet var title: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
