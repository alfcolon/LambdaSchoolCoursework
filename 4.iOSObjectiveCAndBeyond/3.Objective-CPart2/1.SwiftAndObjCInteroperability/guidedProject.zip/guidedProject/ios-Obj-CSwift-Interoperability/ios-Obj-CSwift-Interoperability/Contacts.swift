//
//  Contacts.swift
//  ios-Obj-CSwift-Interoperability
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

import Foundation

@objc(LSIContact)
class Contact: NSObject {
    @objc var name: String
    @objc var relationship: String?
    
    @objc init(name:String, relationship: String?) {
        self.name = name
        self.relationship = relationship
    }
}
