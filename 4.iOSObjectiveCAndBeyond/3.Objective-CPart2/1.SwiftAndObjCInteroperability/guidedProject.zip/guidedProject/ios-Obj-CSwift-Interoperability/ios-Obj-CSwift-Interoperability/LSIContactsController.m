//
//  LSIContactsController.m
//  ios-Obj-CSwift-Interoperability
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import "LSIContactsController.h"
#imort "ios-Obj-CSwift-Interoperability-Swift.h"
#import "Contacts-Swift.h"

@implementation LSIContactsController

@end
