//
//  Contacts-Bridging-Header.h
//  ios-Obj-CSwift-Interoperability
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#ifndef Contacts_Bridging_Header_h
#define Contacts_Bridging_Header_h

#import "LSIContactsController.h"
//#import "Contacts-Swift.h"

#endif /* Contacts_Bridging_Header_h */
