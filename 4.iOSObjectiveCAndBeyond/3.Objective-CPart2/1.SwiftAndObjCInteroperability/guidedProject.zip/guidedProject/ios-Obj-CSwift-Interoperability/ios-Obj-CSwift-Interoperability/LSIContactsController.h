//
//  LSIContactsController.h
//  ios-Obj-CSwift-Interoperability
//
//  Created by Alfredo Colon on 9/3/20.
//  Copyright © 2020 Alfredo Colon. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LSIContact;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(ContactsController)

@interface LSIContactsController : NSObject

@property (nonatomic, readonly, nonnull) NSArray<LSIContact *>*contacts;

@end

NS_ASSUME_NONNULL_END
