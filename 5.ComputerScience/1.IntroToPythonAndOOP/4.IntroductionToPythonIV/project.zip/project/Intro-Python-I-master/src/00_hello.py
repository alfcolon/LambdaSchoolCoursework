# Print "Hello, world!" to your terminal
print("Hello, world!")
